import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const SuperadminRoute = ({ children }) => {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" replace />;
  
  if (user.role !== 'superadmin') {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default SuperadminRoute;
