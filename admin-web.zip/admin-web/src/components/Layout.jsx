import { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Layout({ children }) {
  const { user, mandal, logout } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [showQuickAdd, setShowQuickAdd] = useState(false);

  const links = [
    { to: '/', labelMr: 'डॅशबोर्ड', labelEn: 'Dashboard', icon: '📊', end: true },
    { to: '/collections', labelMr: 'वर्गणी / जमा', labelEn: 'Collections', icon: '🚩' },
    { to: '/receipts', labelMr: 'देणगी पावत्या', labelEn: 'Receipts', icon: '🧾' },
    { to: '/approvals', labelMr: 'मंजुऱ्या', labelEn: 'Approvals', icon: '⏳' },
    { to: '/expenses', labelMr: 'खर्च', labelEn: 'Expenses', icon: '💸' },
    { to: '/chat', labelMr: 'समिती संवाद', labelEn: 'Committee Chat', icon: '💬' },
    { to: '/events', labelMr: 'कार्यक्रम', labelEn: 'Events', icon: '🎪' },
    { to: '/members', labelMr: 'कार्यकारिणी', labelEn: 'Team Members', icon: '👥' },
    { to: '/subscription', labelMr: 'सदस्यता योजना', labelEn: 'Subscription', icon: '💎' },
    { to: '/profile', labelMr: 'मंडळ प्रोफाइल', labelEn: 'Mandal Profile', icon: '🏛️' },
    { to: '/reports', labelMr: 'अहवाल', labelEn: 'Reports', icon: '📑' },
    { to: '/settings', labelMr: 'सेटिंग्ज', labelEn: 'Settings', icon: '⚙️' }
  ];

  const mobileNavLinks = [
    { to: '/', labelMr: 'मुख्यपृष्ठ', labelEn: 'Home', icon: '🏠' },
    { to: '/collections', labelMr: 'वर्गणी', labelEn: 'Vargani', icon: '🚩' },
    { to: '/chat', labelMr: 'संवाद', labelEn: 'Chat', icon: '💬' },
    { to: '/profile', labelMr: 'प्रोफाइल', labelEn: 'Profile', icon: '👤' }
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleLanguage = () => {
    setLanguage(language === 'mr' ? 'en' : 'mr');
  };

  return (
    <div className="app-shell">
      {/* ── Desktop Sidebar ── */}
      <aside className="desktop-sidebar">
        <div className="brand" onClick={() => navigate('/')} style={{ cursor: 'pointer' }}>
          <div className="brand-logo-icon">🪔</div>
          <div className="brand-text">
            Apla<span>Mandal</span>
            <span className="brand-sub">{mandal?.name ? mandal.name.slice(0, 18) : 'MandalPro'}</span>
          </div>
        </div>

        <nav>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end}>
              <span>{l.icon}</span> {language === 'mr' ? l.labelMr : l.labelEn}
            </NavLink>
          ))}

          {user?.role === 'superadmin' && (
            <div style={{ marginTop: 20, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
              <NavLink to="/superadmin">
                <span>🛡️</span> Superadmin
              </NavLink>
            </div>
          )}
        </nav>
      </aside>

      <div className="main-area">
        {/* ── Desktop Topbar ── */}
        <header className="topbar">
          <div className="topbar-left">
            <span className="topbar-mandal-badge">
              🚩 {mandal?.name || 'श्री गणेश मित्र मंडळ'}
            </span>
          </div>

          <div className="topbar-right">
            {/* Language Switch Button */}
            <button
              className="btn-lang-toggle"
              onClick={toggleLanguage}
              title="Switch Language / भाषा बदला"
            >
              <span className="lang-icon">🌐</span>
              <span className="lang-text">{language === 'mr' ? 'मराठी' : 'English'}</span>
            </button>

            <button className="btn btn-primary btn-quick-add" onClick={() => setShowQuickAdd(true)}>
              + New
            </button>

            <div className="avatar-chip" onClick={() => navigate('/profile')} title="My Profile">
              <div className="avatar">{user?.name?.[0]?.toUpperCase() || 'M'}</div>
              <div className="avatar-info-desktop">
                <span className="avatar-name">{user?.name || 'Member'}</span>
                <span className="avatar-role">{user?.role || 'volunteer'}</span>
              </div>
            </div>

            <button className="btn btn-outline btn-sm" onClick={handleLogout} title={t('common.logout')}>
              <span>🚪</span>
            </button>
          </div>
        </header>

        {/* ── Content ── */}
        <div className="content">{children}</div>
      </div>

      {/* Floating Chat Shortcut Button */}
      {location.pathname !== '/chat' && (
        <button
          className="floating-chat-btn"
          onClick={() => navigate('/chat')}
          title="Open Committee Live Chat"
        >
          <span>💬</span>
          <span className="floating-chat-label">{language === 'mr' ? 'समिती संवाद' : 'Chat'}</span>
        </button>
      )}

      {/* ── Mobile Bottom Navigation ── */}
      <nav className="mobile-nav">
        {mobileNavLinks.slice(0, 2).map((l) => (
          <NavLink key={l.to} to={l.to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} end={l.to === '/'}>
            <span>{l.icon}</span>
            <span>{language === 'mr' ? l.labelMr : l.labelEn}</span>
          </NavLink>
        ))}

        {/* Floating Quick Action Center Button */}
        <div className="nav-item nav-fab-wrapper">
          <button className="nav-fab" onClick={() => setShowQuickAdd(true)}>+</button>
        </div>

        {mobileNavLinks.slice(2).map((l) => (
          <NavLink key={l.to} to={l.to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <span>{l.icon}</span>
            <span>{language === 'mr' ? l.labelMr : l.labelEn}</span>
          </NavLink>
        ))}
      </nav>

      {/* ── Quick Add Bottom Sheet ── */}
      {showQuickAdd && (
        <div className="sheet-backdrop" onClick={() => setShowQuickAdd(false)}>
          <div className="bottom-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle"></div>
            <h2 className="text-h2" style={{ fontSize: 18, marginBottom: 16 }}>
              {language === 'mr' ? 'तुम्हाला काय जोडायचे आहे?' : 'What would you like to add?'}
            </h2>
            
            <div className="quick-add-grid">
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/collections'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(249, 115, 22, 0.12)', color: '#F97316' }}>🚩</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('nav.collection')}</div>
              </div>
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/receipts'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(16, 185, 129, 0.12)', color: '#10B981' }}>🧾</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('nav.receipts')}</div>
              </div>
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/expenses'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(239, 68, 68, 0.12)', color: '#EF4444' }}>💸</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('nav.expenses')}</div>
              </div>
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/chat'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(99, 102, 241, 0.12)', color: '#6366F1' }}>💬</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('nav.chat')}</div>
              </div>
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/events'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(108, 77, 217, 0.12)', color: '#6C4DD9' }}>🎪</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('nav.events')}</div>
              </div>
              <div className="quick-add-item" onClick={() => { setShowQuickAdd(false); navigate('/members'); }}>
                <div className="quick-add-icon" style={{ background: 'rgba(59, 130, 246, 0.12)', color: '#3B82F6' }}>👥</div>
                <div className="text-h3" style={{ fontSize: 13.5 }}>{t('profile.addMember')}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
