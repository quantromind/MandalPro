import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import client from '../api/client';
import Layout from '../components/Layout';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [recentDonations, setRecentDonations] = useState([]);
  const [pendingExpenses, setPendingExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const { user, mandal } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();

  const isSuperAdmin = user?.role === 'superadmin';
  const isPresident = user?.role === 'president' || user?.role === 'superadmin' || user?.role === 'treasurer';

  const inr = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;

  const loadData = async () => {
    try {
      setLoading(true);
      const [sumRes, donRes, expRes] = await Promise.all([
        client.get('/dashboard/summary').catch(() => ({ data: {} })),
        client.get('/donations').catch(() => ({ data: [] })),
        client.get('/expenses').catch(() => ({ data: [] }))
      ]);

      setSummary(sumRes.data || {});
      if (Array.isArray(donRes.data)) {
        setRecentDonations(donRes.data.slice(0, 5));
      }
      if (Array.isArray(expRes.data)) {
        const pending = expRes.data.filter((e) => e.status === 'Submitted' || e.status === 'pending');
        setPendingExpenses(pending);
      }
    } catch (err) {
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const totalInflow = summary?.totalInflow || recentDonations.reduce((s, d) => s + (Number(d.amount) || 0), 0);
  const totalOutflow = summary?.totalOutflow || 0;
  const netBalance = totalInflow - totalOutflow;

  return (
    <Layout>
      {/* Top Welcome Banner */}
      <div className="festival-banner">
        <div className="festival-banner-content">
          <div className="badge badge-festive">
            {isPresident ? t('dashboard.presidentWorkspace') : t('dashboard.committeeMember')}
          </div>
          <h1 className="banner-greeting">
            {t('dashboard.greeting', { name: user?.name?.split(' ')[0] || 'Member' })}
          </h1>
          <p className="banner-sub">
            🚩 <strong>{mandal?.name || 'श्री गणेश मित्र मंडळ'}</strong> • {t('dashboard.liveMandalStats')}
          </p>
        </div>
        <div className="festival-banner-actions">
          <button className="btn btn-primary" onClick={() => navigate('/collections')}>
            ✨ {t('collection.recordNewDonation')}
          </button>
        </div>
      </div>

      {error && <div className="error-banner" style={{ marginTop: 16 }}>{error}</div>}

      {/* ── Key Financial Overview Grid ── */}
      <div className="grid-4" style={{ marginTop: 24 }}>
        <div className="card stat-card stat-primary">
          <div className="stat-label">💰 {t('common.inflow')} ({t('collections.title')})</div>
          <div className="stat-val" style={{ color: '#10B981' }}>{inr(totalInflow)}</div>
          <div className="stat-sub">Total collections recorded</div>
        </div>

        <div className="card stat-card stat-cash">
          <div className="stat-label">💸 {t('common.outflow')} ({t('expenses.title')})</div>
          <div className="stat-val" style={{ color: '#EF4444' }}>{inr(totalOutflow)}</div>
          <div className="stat-sub">Approved event expenditures</div>
        </div>

        <div className="card stat-card stat-upi">
          <div className="stat-label">⚖️ {language === 'mr' ? 'शिल्लक रक्कम' : 'Net Balance'}</div>
          <div className="stat-val" style={{ color: '#6366F1' }}>{inr(netBalance)}</div>
          <div className="stat-sub">Available mandal funds</div>
        </div>

        <div className="card stat-card" style={{ borderTop: '3px solid #F59E0B' }} onClick={() => navigate('/approvals')}>
          <div className="stat-label">⏳ {t('dashboard.pendingApprovals')}</div>
          <div className="stat-val" style={{ color: '#F59E0B' }}>{pendingExpenses.length}</div>
          <div className="stat-sub">{pendingExpenses.length > 0 ? 'Action required →' : 'All clear ✓'}</div>
        </div>
      </div>

      {/* ── Quick Actions Grid ── */}
      <div style={{ marginTop: 30 }}>
        <div className="section-header">
          <h3 className="text-h3" style={{ margin: 0 }}>⚡ {t('dashboard.quickActions')}</h3>
          <span className="text-muted" style={{ fontSize: 13 }}>{t('dashboard.frequentlyUsedTools')}</span>
        </div>

        <div className="quick-tools-grid" style={{ marginTop: 14 }}>
          <div className="card tool-card" onClick={() => navigate('/collections')}>
            <div className="tool-icon" style={{ background: 'rgba(249, 115, 22, 0.12)', color: '#F97316' }}>🚩</div>
            <div className="tool-body">
              <div className="tool-title">{t('dashboard.newCollection')}</div>
              <div className="tool-desc">{t('dashboard.newCollectionSub')}</div>
            </div>
          </div>

          <div className="card tool-card" onClick={() => navigate('/receipts')}>
            <div className="tool-icon" style={{ background: 'rgba(16, 185, 129, 0.12)', color: '#10B981' }}>🧾</div>
            <div className="tool-body">
              <div className="tool-title">{t('dashboard.viewShareReceipts')}</div>
              <div className="tool-desc">{t('dashboard.viewShareReceiptsSub')}</div>
            </div>
          </div>

          <div className="card tool-card" onClick={() => navigate('/chat')}>
            <div className="tool-icon" style={{ background: 'rgba(99, 102, 241, 0.12)', color: '#6366F1' }}>💬</div>
            <div className="tool-body">
              <div className="tool-title">{t('chat.title')}</div>
              <div className="tool-desc">{t('chat.groupSubtitle')}</div>
            </div>
          </div>

          <div className="card tool-card" onClick={() => navigate('/approvals')}>
            <div className="tool-icon" style={{ background: 'rgba(245, 158, 11, 0.12)', color: '#F59E0B' }}>⏳</div>
            <div className="tool-body">
              <div className="tool-title">{t('dashboard.expensesApprovals')}</div>
              <div className="tool-desc">{t('dashboard.expensesApprovalsSub')}</div>
            </div>
          </div>

          <div className="card tool-card" onClick={() => navigate('/profile')}>
            <div className="tool-icon" style={{ background: 'rgba(139, 92, 246, 0.12)', color: '#8B5CF6' }}>🪪</div>
            <div className="tool-body">
              <div className="tool-title">{t('idCard.title')}</div>
              <div className="tool-desc">{t('idCard.subtitle')}</div>
            </div>
          </div>

          <div className="card tool-card" onClick={() => navigate('/subscription')}>
            <div className="tool-icon" style={{ background: 'rgba(236, 72, 153, 0.12)', color: '#EC4899' }}>💎</div>
            <div className="tool-body">
              <div className="tool-title">{t('subscription.title')}</div>
              <div className="tool-desc">{t('subscription.managePlan')}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Recent Vargani & Activities ── */}
      <div className="grid-2" style={{ marginTop: 30 }}>
        {/* Recent Collections */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 className="text-h3" style={{ margin: 0 }}>🚩 {t('collections.title')} (Recent)</h3>
            <Link to="/collections" className="text-primary" style={{ fontSize: 13, fontWeight: 700 }}>
              {language === 'mr' ? 'सर्व पहा →' : 'View All →'}
            </Link>
          </div>

          {recentDonations.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 24 }} className="text-muted">
              {t('collections.noCollectionsYet')}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {recentDonations.map((d) => (
                <div key={d._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'var(--bg-subtle, #f8f9fa)', borderRadius: 8 }}>
                  <div>
                    <div style={{ fontWeight: 700, color: 'var(--text-main)', fontSize: 14 }}>
                      {d.contributor || d.donorName}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                      {d.title || d.purpose || 'वर्गणी'} • {d.paymentMode || 'Cash'}
                    </div>
                  </div>
                  <div style={{ fontWeight: 800, color: '#10B981', fontSize: 15 }}>
                    +{inr(d.amount)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Approvals Widget */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 className="text-h3" style={{ margin: 0 }}>⏳ {t('approvals.title')}</h3>
            <Link to="/approvals" className="text-primary" style={{ fontSize: 13, fontWeight: 700 }}>
              {language === 'mr' ? 'तपासा →' : 'Review →'}
            </Link>
          </div>

          {pendingExpenses.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 24 }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>🎉</div>
              <div style={{ fontWeight: 600, color: 'var(--text-main)' }}>{t('approvals.allCaughtUp')}</div>
              <p className="text-muted" style={{ fontSize: 12.5, margin: 0 }}>{t('approvals.noPendingSub')}</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {pendingExpenses.slice(0, 4).map((e) => (
                <div key={e._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: '#FEF3C7', borderRadius: 8, borderLeft: '3px solid #F59E0B' }}>
                  <div>
                    <div style={{ fontWeight: 700, color: '#92400E', fontSize: 14 }}>{e.title || e.category}</div>
                    <div style={{ fontSize: 12, color: '#B45309' }}>{e.vendor || 'Vendor'} • ⏳ Pending</div>
                  </div>
                  <div style={{ fontWeight: 800, color: '#EF4444', fontSize: 15 }}>
                    {inr(e.amount)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
