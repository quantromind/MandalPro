import { useState, useEffect } from 'react';
import client from '../api/client';
import Layout from '../components/Layout';
import ReceiptModal from '../components/ReceiptModal';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Receipts() {
  const [receipts, setReceipts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState(null);

  const { mandal, user } = useAuth();
  const { t, language } = useLanguage();

  const inr = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;

  const loadReceipts = async () => {
    try {
      setLoading(true);
      const { data } = await client.get('/donations');
      if (Array.isArray(data)) {
        setReceipts(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReceipts();
  }, []);

  const filtered = receipts.filter((r) => {
    const donor = (r.contributor || r.donorName || '').toLowerCase();
    const id = (r.receiptNumber || r._id || '').toLowerCase();
    const mob = (r.mobile || r.donorMobile || '');
    const q = search.toLowerCase();
    return donor.includes(q) || id.includes(q) || mob.includes(q);
  });

  return (
    <Layout>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
        <div>
          <h1 className="text-h1" style={{ margin: 0 }}>
            🧾 {t('receipts.title')} (देणगी पावत्या)
          </h1>
          <p className="text-muted" style={{ marginTop: 4 }}>
            {t('dashboard.viewShareReceiptsSub')}
          </p>
        </div>
      </div>

      {/* Search Filter */}
      <div className="card" style={{ marginTop: 20, padding: 16 }}>
        <input
          type="text"
          placeholder={t('common.search') + " (Donor name, mobile, receipt #)"}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="form-control"
        />
      </div>

      {/* Receipts Grid */}
      <div style={{ marginTop: 16 }}>
        {loading ? (
          <div className="card" style={{ padding: 40, textAlign: 'center' }}>
            <div className="spinner"></div>
            <p className="text-muted" style={{ marginTop: 10 }}>{t('common.loading')}</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="card" style={{ padding: 50, textAlign: 'center' }}>
            <div style={{ fontSize: 44, marginBottom: 12 }}>🧾</div>
            <h3 className="text-h3">{t('receipts.noReceiptsYet')}</h3>
            <p className="text-muted">{t('receipts.noReceiptsSub')}</p>
          </div>
        ) : (
          <div className="grid-1" style={{ gap: 12 }}>
            {filtered.map((r) => {
              const d = r.date || r.createdAt ? new Date(r.date || r.createdAt) : new Date();
              const dateStr = `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
              const rNo = r.receiptNumber || r._id?.slice(-6)?.toUpperCase();

              return (
                <div key={r._id} className="card receipt-row-card">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, flex: 1 }}>
                    <div className="receipt-icon-badge">🧾</div>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 16, color: 'var(--text-main)' }}>
                        {r.contributor || r.donorName}
                      </div>
                      <div className="text-muted" style={{ fontSize: 13, marginTop: 2 }}>
                        <span>#{rNo}</span> • <span>📅 {dateStr}</span> •{' '}
                        <span>{r.paymentMode === 'cash' ? '💵 Cash' : '📱 UPI'}</span>
                        {r.mobile || r.donorMobile ? ` • 📞 +91 ${r.mobile || r.donorMobile}` : ''}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--primary)' }}>
                      {inr(r.amount)}
                    </div>
                    <button
                      className="btn btn-sm btn-primary"
                      style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                      onClick={() => setSelectedReceipt(r)}
                    >
                      <span>📲</span> {t('receipts.share')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Receipt Modal */}
      {selectedReceipt && (
        <ReceiptModal
          visible={!!selectedReceipt}
          receipt={selectedReceipt}
          mandal={mandal}
          collectorName={user?.name}
          onClose={() => setSelectedReceipt(null)}
        />
      )}
    </Layout>
  );
}
