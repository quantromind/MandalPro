import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import api from '../api/axios';

export default function Login() {
  const [authMode, setAuthMode] = useState('otp'); // 'otp' | 'password'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();

  const handleSendOtp = async (e) => {
    e?.preventDefault();
    if (!email || !email.includes('@')) {
      setError(language === 'mr' ? 'कृपया वैध ईमेल पत्ता प्रविष्ट करा' : 'Please enter a valid email address');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/send-otp', { email: email.trim().toLowerCase(), purpose: 'login' });
      setOtpSent(true);
    } catch (err) {
      setError(err.response?.data?.message || (language === 'mr' ? 'OTP पाठवण्यात अयशस्वी' : 'Failed to send OTP'));
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtpLogin = async (e) => {
    e?.preventDefault();
    if (!otp || otp.trim().length < 6) {
      setError(language === 'mr' ? 'कृपया ६ अंकी OTP प्रविष्ट करा' : 'Please enter 6-digit OTP');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const { data } = await api.post('/auth/login-otp', {
        email: email.trim().toLowerCase(),
        code: otp.trim()
      });
      localStorage.setItem('mandalpro_token', data.token);
      localStorage.setItem('mandalpro_user', JSON.stringify(data.user));
      if (data.mandal) localStorage.setItem('mandalpro_mandal', JSON.stringify(data.mandal));

      navigate('/');
      window.location.reload();
    } catch (err) {
      setError(err.response?.data?.message || (language === 'mr' ? 'अवैध OTP' : 'Invalid OTP'));
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordLogin = async (e) => {
    e?.preventDefault();
    if (!email || !password) {
      setError(language === 'mr' ? 'ईमेल आणि पासवर्ड आवश्यक आहे' : 'Email and password required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await login(email.trim().toLowerCase(), password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || (language === 'mr' ? 'लॉगिन अयशस्वी. ईमेल किंवा पासवर्ड तपासा.' : 'Login failed. Check your credentials.'));
    } finally {
      setLoading(false);
    }
  };

  const quickDemoLogin = async (type) => {
    setError('');
    setLoading(true);
    try {
      if (type === 'superadmin') {
        setEmail('quantromind@gmail.com');
        setAuthMode('otp');
        await api.post('/auth/send-otp', { email: 'quantromind@gmail.com', purpose: 'login' });
        setOtpSent(true);
        setOtp('123456');
      } else if (type === 'demo') {
        setEmail('demo@mandalpro.com');
        setAuthMode('otp');
        await api.post('/auth/send-otp', { email: 'demo@mandalpro.com', purpose: 'login' });
        setOtpSent(true);
        setOtp('123456');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Demo request failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      {/* Top Floating Language Switcher */}
      <div style={{ position: 'absolute', top: 20, right: 24, zIndex: 10 }}>
        <button
          className="btn-lang-toggle"
          onClick={() => setLanguage(language === 'mr' ? 'en' : 'mr')}
        >
          <span>🌐</span> {language === 'mr' ? 'English' : 'मराठी'}
        </button>
      </div>

      <div className="auth-card" style={{ maxWidth: 460 }}>
        {/* Logo */}
        <div className="auth-logo" style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ width: 44, height: 44, background: 'var(--primary)', color: '#fff', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, marginRight: 12, boxShadow: '0 4px 12px rgba(249,115,22,0.3)' }}>
            🪔
          </div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>
            Apla<span style={{ color: 'var(--primary)' }}>Mandal</span>
          </div>
        </div>

        <h1 className="text-h1" style={{ fontSize: 22, marginBottom: 6 }}>
          {language === 'mr' ? 'मंडळ व्यवस्थापन. सोपे आणि डिजिटल.' : 'Manage your Mandal. Smarter. Together.'}
        </h1>
        <p className="text-sub" style={{ marginBottom: 20, fontSize: 13.5 }}>
          {language === 'mr' ? 'वर्गणी, पावत्या, खर्च व समिती संवाद एकाच ठिकाणी.' : 'Everything you need to organize festivals, collections, receipts & committee.'}
        </p>

        {/* Auth Mode Tabs (OTP vs Password) */}
        <div className="tab-pill-group" style={{ marginBottom: 20 }}>
          <button
            type="button"
            className={`tab-pill ${authMode === 'otp' ? 'active' : ''}`}
            onClick={() => { setAuthMode('otp'); setError(''); }}
            style={{ flex: 1 }}
          >
            📱 {language === 'mr' ? 'OTP द्वारे साइन इन' : 'OTP Sign In'}
          </button>
          <button
            type="button"
            className={`tab-pill ${authMode === 'password' ? 'active' : ''}`}
            onClick={() => { setAuthMode('password'); setError(''); }}
            style={{ flex: 1 }}
          >
            🔑 {language === 'mr' ? 'पासवर्ड' : 'Password'}
          </button>
        </div>

        {error && (
          <div style={{ padding: '12px 16px', background: '#FEF2F2', border: '1px solid #FCA5A5', color: '#B91C1C', borderRadius: 10, fontSize: 13.5, fontWeight: 600, marginBottom: 18 }}>
            {error}
          </div>
        )}

        {/* ── OTP Sign In Flow ── */}
        {authMode === 'otp' ? (
          <div>
            {!otpSent ? (
              <form onSubmit={handleSendOtp}>
                <div className="field">
                  <label>{t('auth.emailLabel')}</label>
                  <input
                    type="email"
                    placeholder="president@yourmandal.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    autoFocus
                  />
                </div>
                <button type="submit" className="btn btn-primary w-full" style={{ padding: '14px', fontSize: 15, marginTop: 10 }} disabled={loading}>
                  {loading ? t('common.loading') : `${t('auth.sendOtp')}`}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtpLogin}>
                <div style={{ background: 'rgba(249, 115, 22, 0.06)', padding: '12px 14px', borderRadius: 10, marginBottom: 16, border: '1px dashed #FDBA74' }}>
                  <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>{t('auth.otpSubtitle', { email })}</div>
                  <button type="button" onClick={() => { setOtpSent(false); setOtp(''); }} style={{ background: 'none', border: 'none', color: 'var(--primary)', fontWeight: 700, fontSize: 12, cursor: 'pointer', padding: 0, marginTop: 4 }}>
                    {t('auth.changeEmail')}
                  </button>
                </div>

                <div className="field">
                  <label>{t('auth.otpVerification')} (६ अंकी कोड)</label>
                  <input
                    type="text"
                    placeholder="123456"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    maxLength={6}
                    style={{ letterSpacing: 6, fontWeight: 800, fontSize: 18, textAlign: 'center' }}
                    required
                    autoFocus
                  />
                </div>

                <button type="submit" className="btn btn-primary w-full" style={{ padding: '14px', fontSize: 15, marginTop: 10 }} disabled={loading}>
                  {loading ? t('common.loading') : `✓ ${t('auth.verifyOtp')}`}
                </button>
              </form>
            )}
          </div>
        ) : (
          /* ── Password Sign In Flow ── */
          <form onSubmit={handlePasswordLogin}>
            <div className="field">
              <label>{t('auth.emailLabel')}</label>
              <input
                type="email"
                placeholder="president@yourmandal.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label>पासवर्ड / Password</label>
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary w-full" style={{ padding: '14px', fontSize: 15, marginTop: 10 }} disabled={loading}>
              {loading ? t('common.loading') : 'Sign In →'}
            </button>
          </form>
        )}

        {/* Demo Fast Logins for Testing */}
        <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px dashed var(--border)', textAlign: 'center' }}>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginBottom: 8 }}>
            ⚡ QUICK TEST DEMO:
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            <button
              type="button"
              className="chip-btn"
              onClick={() => quickDemoLogin('demo')}
              title="Test President Login (demo@mandalpro.com)"
            >
              👑 Demo President
            </button>
            <button
              type="button"
              className="chip-btn"
              onClick={() => quickDemoLogin('superadmin')}
              title="Superadmin Login"
            >
              🛡️ Superadmin
            </button>
          </div>
        </div>

        <p style={{ textAlign: 'center', margin: '20px 0 0', color: 'var(--text-muted)', fontSize: 14 }}>
          {language === 'mr' ? 'नवीन मंडळ नोंदणी करायची आहे?' : "Don't have an account yet?"}{' '}
          <Link to="/register" style={{ color: 'var(--primary)', fontWeight: 700 }}>
            {language === 'mr' ? 'नवीन खाते तयार करा →' : 'Register Mandal →'}
          </Link>
        </p>

        <div className="auth-footer" style={{ marginTop: 20, fontSize: 11.5, textAlign: 'center', color: 'var(--text-muted)' }}>
          By continuing, you agree to our <Link to="/terms-and-conditions">Terms &amp; Conditions</Link> &amp; <Link to="/privacy-policy">Privacy Policy</Link>
        </div>
      </div>
    </div>
  );
}
